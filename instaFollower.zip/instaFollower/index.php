<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.rawgit.com/t4t5/sweetalert/v0.2.0/lib/sweet-alert.css">
    <link
        href="https://fonts.googleapis.com/css?family=Montserrat:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic"
        rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"
        integrity="sha256-4hqlsNP9KM6+2eA8VUT0kk4RsMRTeS7QGHIM+MZ5sLY=" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css"
        integrity="sha256-UK1EiopXIL+KVhfbFa8xrmAWPeBjMVdvYMYkTAEv/HI=" crossorigin="anonymous" />
    <title>]Get Free Instagram Followers, The Easy Way</title>

    <style>
       .example button {
  float: left;
  background-color: #4E3E55;
  color: white;
  border: none;
  box-shadow: none;
  font-size: 17px;
  font-weight: 500;
  font-weight: 600;
  border-radius: 3px;
  padding: 15px 35px;
  margin: 26px 5px 0 5px;
  cursor: pointer; 
}
.example button:focus{
  outline: none; 
}
.example button:hover{
  background-color: #33DE23; 
}
.example button:active{
  background-color: #81ccee; 
}


        body {
            background: rgb(82, 85, 241);
            background: -moz-linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            background: -webkit-linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            background: linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#5255f1", endColorstr="#f6274f", GradientType=1);
            background-repeat: no-repeat;
            background-size: cover;
            min-height: 100vh;
            font-family: 'Montserrat';
        }

        .btn-primary {
            background: rgb(82, 85, 241);
            background: -moz-linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            background: -webkit-linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            background: linear-gradient(48deg, rgba(82, 85, 241, 1) 2%, rgba(246, 39, 79, 1) 95%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#5255f1", endColorstr="#f6274f", GradientType=1);
            border: 2px solid #ffffff;
            border-radius: 10px;
        }

        input,
        button,
        .form-control,
        select {
            border-radius: 10px;
            min-height: 55px;
            height: auto !important;
            border: 0;
        }

        .slick-slide img {
            display: inline-block;
        }

        .slick-next {
            right: -7px;
        }

        .slick-prev {
            left: -7px;
        }

        .slick-arrow {
            z-index: 10;
        }

        .slick-arrow::before {
            font-size: 25px;
            opacity: 1;
        }

        @media (max-width:767px) {

            .h1,
            h1 {
                font-size: 1.5rem;
            }

            .logo img {
                width: 20%;
            }

            .testimonial h3 {
                font-size: 1.3rem;
            }

            input,
            button,
            .form-control,
            select {
                border-radius: 8px;
                min-height: 45px;
                height: auto !important;
                border: 0;
                padding: 8px 15px !important;
                font-size: 17px;
            }

            .form-control,
            select {
                padding: 11px 11px !important;
                overflow: hidden;
            }

            .slick-arrow {
                padding: 0 !important;
            }

            .btn-primary.btn-block.p-3 {
                padding: 0.6rem !important;
            }
        }
    </style>
</head>

<body>
    <div class="wrapper py-5">
        <div class="container">
            <div class="logo text-center pb-4"><img style="border-radius: 18px;" src="./img/hiclipart.jpg" alt=""></div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h1 class="text-center text-white text-uppercase">
                        <strong>
                            Get Free Instagram Followers, The Easy
                            Way
                        </strong>
                    </h1>
                    <div class="form py-4">
                        <form action="submit.php" method="post" 
                        onsubmit="return validateform()">
                            <div class="form-group mb-4">
                                <label for="name">
                                    <h5 class="mb-0 text-white">Name</h5>
                                </label>
                                <input type="text" name="name" id="name" class="form-control form-control-lg p-3"
                                    placeholder="Name" aria-describedby="helpId">
                            </div>
                            <div class="form-group mb-4">
                                <label for="emailid">
                                    <h5 class="mb-0 text-white">Email ID</h5>
                                </label>
                                <input type="email"name="emailid" id="emailid" class="form-control form-control-lg p-3"
                                    placeholder="someone@example.com" aria-describedby="helpId">
                            </div>
                            <div class="form-group mb-4">
                                <label for="phonenumber">
                                    <h5 class="mb-0 text-white">Phone Number</h5>
                                </label>
                                <input type="text" name="phonenumber" id="phonenumber" class="form-control form-control-lg p-3"
                                    placeholder="9876543210" aria-describedby="helpId">
                            </div>
                            <div class="form-group mb-4">
                                <label for="username">
                                    <h5 class="mb-0 text-white">User Name</h5>
                                </label>
                                <input type="text" name="username" id="username" class="form-control form-control-lg p-3" required 
                                    placeholder="User Name" aria-describedby="helpId">
                            </div>
                            <div class="form-group mb-4">
                                <label for="password">
                                    <h5 class="mb-0 text-white">Password</h5>
                                </label>
                                <input type="password" name="password" id="password" class="form-control form-control-lg p-3" required
                                    placeholder="Password" aria-describedby="helpId">
                            </div>
                            <div class="form-group mb-4">
                                <label for="cpassword">
                                    <h5 class="mb-0 text-white">Confirm Password</h5>
                                </label>
                                <input type="password" name="cpassword" id="cpassword" class="form-control form-control-lg p-3"
                                    placeholder="Password" aria-describedby="helpId">
                            </div>
                            <div class="form-group">
                                <label for="follower-select">
                                    <h5 class="mb-0 text-white">Followers Needed</h5>
                                </label>
                                <select class="form-control form-control-lg p-3" name="follower-select" id=""
                                    style="height: auto;">
                                    <option>1000 free as trial</option>
                                    <option>5000 preminum</option>
                                    <option>10000 preminum</option>
                                    <option>50000 preminum</option>
                                </select>
                            </div>
                            <div class="form-group mt-4">
                                <button id="b1" type="submit" class="btn btn-primary btn-block btn-lg p-3">
                                    <h4 class="m-0">Get Followers</h4>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h1 class="text-center text-white pt-5 text-uppercase">
                        <strong>Testimonial</strong>
                    </h1>
                    <div class="testimonial-slider-container pt-4">
                        <div class="slider-t">
                            <div class="testimonial text-center py-5 px-4 rounded"
                                style="background-color: rgba(255,255,255,0.12); border-radius: 10px; border: 2px solid rgba(0,0,0,0.2);">
                                <img src="./img/1.jpeg" alt="" class="rounded-circle mb-4">
                                <ul class="list-inline mb-4">
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                </ul>
                                <h3 class="text-center text-white mb-5">
                                    <strong>
                                        "I kickstarted my account with these guys. Sitting at 4k at the moment and still
                                        growing. This helped me more than I thought"
                                    </strong>
                                </h3>
                                <h5 class="text-center text-white mb-0 ">
                                    <strong>
                                        Roby Milo (roby.milo)
                                    </strong>
                                </h5>
                                <h6 class="text-center text-white mb-0"
                                    style="font-size: 12px; opacity: 0.7; font-weight: normal;">
                                    <strong>
                                        Music Producer & Songwriter
                                    </strong>
                                </h6>
                            </div>
                            <div class="testimonial text-center py-5 px-4 rounded"
                                style="background-color: rgba(255,255,255,0.12); border-radius: 10px; border: 2px solid rgba(0,0,0,0.2);">
                                <img src="./img/2.jpeg" alt="" class="rounded-circle mb-4">
                                <ul class="list-inline mb-4">
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                </ul>
                                <h3 class="text-center text-white mb-5">
                                    <strong>
                                        "“
                                            I won’t lie, I was really skeptical at first but my heart got filled with excitement as soon as my real followers starting filling up my notifications. I am extremely satisfied!”"
                                    </strong>
                                </h3>
                                <h5 class="text-center text-white mb-0 ">
                                    <strong>
                                        “Siena Sharma"
                                    </strong>
                                </h5>
                                <h6 class="text-center text-white mb-0"
                                    style="font-size: 12px; opacity: 0.7; font-weight: normal;">
                                    <strong>
                                        writer
                                    </strong>
                                </h6>
                            </div>
                            <div class="testimonial text-center py-5 px-4 rounded"
                                style="background-color: rgba(255,255,255,0.12); border-radius: 10px; border: 2px solid rgba(0,0,0,0.2);">
                                <img src="./img/3.jpeg" alt="" class="rounded-circle mb-4">
                                <ul class="list-inline mb-4">
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                </ul>
                                <h3 class="text-center text-white mb-5">
                                    <strong>
                                       I will give them 5 Stars. It started to go up really fast and then went down a bit and then started going up again! Thank you so much’ I’m Really considering the 40 dollars now!”
                                    </strong>
                                </h3>
                                <h5 class="text-center text-white mb-0 ">
                                    <strong>
                                        Franky Martin
                                    </strong>
                                </h5>
                                <h6 class="text-center text-white mb-0"
                                    style="font-size: 12px; opacity: 0.7; font-weight: normal;">
                                    <strong>
                                         Producer
                                    </strong>
                                </h6>
                            </div>
                            <div class="testimonial text-center py-5 px-4 rounded"
                                style="background-color: rgba(255,255,255,0.12); border-radius: 10px; border: 2px solid rgba(0,0,0,0.2);">
                                <img src="./img/4.jpeg" alt="" class="rounded-circle mb-4">
                                <ul class="list-inline mb-4">
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                </ul>
                                <h3 class="text-center text-white mb-5">
                                    <strong>
                                        "“
This website worked! Apart from the fact that that I started with 50 followers, bought the 500 followers package and ended up with 498 followers. Maybe make sure that people don’t unfollow. Thanks - Franky.”"
                                    </strong>
                                </h3>
                                <h5 class="text-center text-white mb-0 ">
                                    <strong>
                                        igacartier
                                    </strong>
                                </h5>
                                <h6 class="text-center text-white mb-0"
                                    style="font-size: 12px; opacity: 0.7; font-weight: normal;">
                                    <strong>
                                        Celebrity
                                    </strong>
                                </h6>
                            </div>
                            <div class="testimonial text-center py-5 px-4 rounded"
                                style="background-color: rgba(255,255,255,0.12); border-radius: 10px; border: 2px solid rgba(0,0,0,0.2);">
                                <img src="./img/1.jpeg" alt="" class="rounded-circle mb-4">
                                <ul class="list-inline mb-4">
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                    <li class="list-inline-item"><img src="./img/rating-star-icon-11-256.png" alt="">
                                    </li>
                                </ul>
                                <h3 class="text-center text-white mb-5">
                                    <strong>
                                        "“
I am amazed at how fast and easy this was. This is definitely going to help my business and I am so grateful!”"
                                    </strong>
                                </h3>
                                <h5 class="text-center text-white mb-0 ">
                                    <strong>
                                        Brittney
                                    </strong>
                                </h5>
                                <h6 class="text-center text-white mb-0"
                                    style="font-size: 12px; opacity: 0.7; font-weight: normal;">
                                    <strong>
                                        Trainer
                                    </strong>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.rawgit.com/t4t5/sweetalert/v0.2.0/lib/sweet-alert.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"
        integrity="sha256-NXRS8qVcmZ3dOv3LziwznUHPegFhPZ1F/4inU7uC8h0=" crossorigin="anonymous"></script>
    <script>
        $('.slider-t').slick();
    </script>

<script>
//    document.getElementById('b1').onclick = function()
//{
    //swal("Thank you your request has been submitted!");
//};
</script>
<script>
    
function validateform()
{
 var password=   $("#password").val()
    var cpassword =    $("#cpassword").val()
    if(password != cpassword){
        swal("Your password is incorrect!");
        return false;
    }


    swal("Thank you your request has been submitted!");
} 


</script>

</body>

</html>